# LearnMate - React Login Page

A beautiful and responsive login page for LearnMate learning platform.

## Features

- ✅ Email and password input fields
- ✅ "Let's Go" submit button
- ✅ Create account link for new users
- ✅ Custom owl logo with graduation cap reading a book
- ✅ Welcoming message
- ✅ Modern gradient design
- ✅ Fully responsive
- ✅ Smooth animations

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Install dependencies:
```bash
npm install
```

2. Run the development server:
```bash
npm run dev
```

3. Open your browser and navigate to `http://localhost:5173`

## Project Structure

```
learnmate/
├── src/
│   ├── components/
│   │   ├── Login.jsx       # Main login component
│   │   ├── Login.css       # Login page styles
│   │   ├── Logo.jsx        # Owl logo component
│   │   └── Logo.css        # Logo animations
│   ├── App.jsx             # Root component
│   ├── App.css             # App styles
│   ├── main.jsx            # Entry point
│   └── index.css           # Global styles
├── index.html
├── package.json
└── vite.config.js
```

## Customization

- Modify colors in `Login.css` to match your brand
- Update the logo in `Logo.jsx` if needed
- Add routing functionality to handle "Create an account" navigation

## Technologies Used

- React 18
- Vite
- CSS3 with animations
- SVG for custom logo

## Next Steps

- Implement authentication logic
- Create registration page
- Add form validation
- Connect to backend API
- Add password recovery feature

Enjoy your learning journey with LearnMate! 🦉📚
