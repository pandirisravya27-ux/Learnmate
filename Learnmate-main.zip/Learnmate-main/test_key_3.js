
const apiKey = 'AIzaSyDeJAOI0yBxcNaJ-gdXGCNF5lkrCWfKPVw';

async function testModel(modelName) {
    console.log(`Testing model: ${modelName}...`);
    try {
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${apiKey}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{ text: "Hello, strictly answer with 'OK'" }]
                }]
            })
        });

        const data = await response.json();

        if (!response.ok) {
            console.error(`Error for ${modelName}: ${response.status}`);
            // console.log(JSON.stringify(data, null, 2));
        } else {
            console.log(`Success for ${modelName}!`);
            console.log("Response:", data.candidates?.[0]?.content?.parts?.[0]?.text || "No text");
        }
    } catch (error) {
        console.error(`Exception for ${modelName}:`, error);
    }
    console.log('---');
}

async function runTests() {
    await testModel('gemini-1.5-flash');
    await testModel('gemini-2.0-flash-exp');
}

runTests();
