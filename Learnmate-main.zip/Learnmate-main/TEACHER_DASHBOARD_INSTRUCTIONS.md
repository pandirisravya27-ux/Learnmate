# Teacher Dashboard Access Instructions

## How to Access the Teacher Dashboard

The Teacher Dashboard has been successfully integrated into your LearnMate application. Here's how to access it:

### Method 1: Direct URL Access
Simply navigate to: **http://localhost:5173/teacher**

### Method 2: Backend API (for testing)
You can also access the API directly at: **http://localhost:5000/api/teacher/student-progress**

## Features

The Teacher Dashboard includes:

✅ **Real-time Student Progress Tracking**
- View all students (up to 72+) in a single dashboard
- LeetCode and HackerRank statistics for each student
- Problem-solving breakdown (Easy, Medium, Hard)
- Rankings and badges

✅ **Search and Filter**
- Search by student name, email, or username
- Filter by platform (All, LeetCode only, HackerRank only)
- Sort by name, LeetCode progress, HackerRank score, or total progress

✅ **Data Management**
- Refresh all student data at once
- Refresh individual student data
- Export to CSV for offline analysis

✅ **Statistics Overview**
- Total students count
- Average problems solved
- Platform usage statistics
- Last updated timestamps

## Setup Instructions

### 1. Start the Backend Server
```bash
cd backend
npm install
node server.js
```

The server should start on http://localhost:5000

### 2. Start the Frontend
```bash
npm install
npm run dev
```

The frontend should start on http://localhost:5173

### 3. Access the Dashboard
Navigate to: http://localhost:5173/teacher

## How Students Add Their Profiles

Students can add their coding profiles by:
1. Logging into their account
2. Going to Dashboard → Coding Profiles
3. Entering their LeetCode and/or HackerRank usernames
4. Clicking Save

Their progress will automatically be visible in the Teacher Dashboard.

## API Endpoints

### Get All Student Progress
```
GET http://localhost:5000/api/teacher/student-progress
```

### Refresh Individual Student
```
POST http://localhost:5000/api/teacher/refresh-student/:userId
```

### Save Student Coding Profiles
```
POST http://localhost:5000/api/coding-profiles/:userId
Body: { "leetcodeUsername": "username", "hackerrankUsername": "username" }
```

## Notes

- The dashboard automatically fetches data from LeetCode and HackerRank APIs
- Data is cached in the users.json file
- You can refresh data anytime using the refresh buttons
- The dashboard is fully responsive and works on tablets and mobile devices
- CSV export includes all student data with timestamps

## Troubleshooting

**Issue: No students showing up**
- Make sure students have registered and added their coding profile usernames
- Check if the backend server is running
- Verify the API endpoint is accessible

**Issue: Stats not updating**
- Click the refresh button to fetch latest data
- Check if the usernames are correct
- Some APIs may have rate limits

**Issue: Cannot access /teacher route**
- Make sure you're using the development server (npm run dev)
- Clear browser cache and reload
- Check console for any errors

## Sample Data

For testing purposes, you can add sample student data by:
1. Creating multiple user accounts
2. Adding coding profile usernames for each
3. The system will fetch real data from LeetCode and HackerRank

Enjoy your new Teacher Dashboard! 🎓
