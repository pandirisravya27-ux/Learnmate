# 🎓 Teacher Dashboard - Complete Access Guide

## ✅ How to Access Teacher Dashboard

### **Option 1: From Student Dashboard**
1. Login to your student account
2. Look at the sidebar navigation
3. Scroll down to the **"Teacher"** section (highlighted in purple)
4. Click on **"👨‍🏫 Teacher Dashboard"**
5. You'll be redirected to the complete teacher view

### **Option 2: Direct URL**
Simply navigate to: `http://localhost:5173/teacher`

---

## 📊 Teacher Dashboard Features

### **1. Student Overview Statistics**
- Total number of students
- Students with LeetCode profiles
- Students with HackerRank profiles
- Average problems solved on LeetCode
- Average score on HackerRank

### **2. Student Table**
For each student, you can see:
- **Name & Email**
- **LeetCode Progress:**
  - Total problems solved
  - Easy/Medium/Hard breakdown
  - Global ranking
- **HackerRank Progress:**
  - Total score
  - Number of badges earned
- **Last updated timestamp**

### **3. Powerful Actions**

#### 🔍 **Search & Filter**
- Search by student name, email, or username
- Filter: All Platforms | LeetCode Only | HackerRank Only
- Sort by: Name | LeetCode Progress | HackerRank Score | Total Progress

#### 📊 **Sync from Google Sheets**
- Click **"📊 Sync from Sheets"**
- Automatically imports all students from your Google Sheet
- Parses LeetCode and HackerRank URLs
- Creates accounts for new students
- Updates existing student profiles

#### 🔄 **Refresh Data**
- **"🔄 Refresh All"** - Updates stats for all students
- **"🔄"** (individual) - Refresh specific student data

#### 👁️ **View Profiles** ⭐
- Click **"👁️ View Profiles"** for any student
- **Opens ALL their coding profiles in new tabs:**
  - LeetCode profile (if available)
  - HackerRank profile (if available)
- Quick access to see their full coding journey!

#### 📥 **Export to CSV**
- Export complete student data for offline analysis
- Includes all stats and timestamps

---

## 🚀 Quick Start Guide

### **Step 1: Ensure Backend is Running**
```bash
cd backend
node server.js
```
Server should start on `http://localhost:5000`

### **Step 2: Ensure Frontend is Running**
```bash
npm run dev
```
Frontend should start on `http://localhost:5173`

### **Step 3: Sync Students from Google Sheets**
1. Go to `http://localhost:5173/teacher`
2. Click **"📊 Sync from Sheets"**
3. Wait for sync to complete
4. You'll see: "✅ Sync Complete! Added: X students, Updated: Y students"

### **Step 4: Refresh Stats**
1. Click **"🔄 Refresh All"** to fetch latest coding stats
2. Wait for data to load (may take a few seconds for 72 students)

### **Step 5: View Student Profiles**
1. Find any student in the table
2. Click **"👁️ View Profiles"**
3. Both LeetCode and HackerRank profiles open in new tabs!

---

## 📋 Google Sheet Format

Your Google Sheet should have these columns:

| Column A | Column B | Column C | Column D | Column E |
|----------|----------|----------|----------|----------|
| **Name** | **Email** | **Roll Number** | **LeetCode URL** | **HackerRank URL** |
| John Doe | john@example.com | 001 | https://leetcode.com/u/johndoe | https://hackerrank.com/profile/johndoe |
| Jane Smith | jane@example.com | 002 | https://leetcode.com/janesmith | https://hackerrank.com/profile/janesmith |

**Supported URL formats:**
- LeetCode: `https://leetcode.com/username` or `https://leetcode.com/u/username`
- HackerRank: `https://www.hackerrank.com/profile/username` or `https://hackerrank.com/username`

---

## 🎯 Use Cases

### **Monitor Class Progress**
- Quickly see which students are actively solving problems
- Identify students who need encouragement
- Track improvement over time

### **Compare Performance**
- Sort by different metrics
- See who's leading in Easy/Medium/Hard problems
- View HackerRank badge counts

### **Quick Profile Access**
- Click "View Profiles" to see student's full coding journey
- Check their recent submissions
- View their contest participation

### **Export for Reports**
- Export CSV for administrative purposes
- Include in progress reports
- Track semester-wise improvement

---

## 🔧 Troubleshooting

### **No students showing?**
1. Click "Sync from Sheets" to import from Google Sheet
2. Ensure backend server is running
3. Check if Google Sheets credentials are properly configured

### **Stats showing "No data"?**
1. Click "Refresh All" to fetch latest stats
2. Verify student usernames are correct
3. Check if students have made their profiles public

### **"View Profiles" not opening?**
1. Ensure pop-ups are not blocked in your browser
2. Check if usernames are correctly saved
3. Verify the URLs are accessible

### **Sync from Sheets failing?**
1. Verify credentials.json exists in backend directory
2. Check if spreadsheet ID is correct
3. Ensure service account has access to the sheet

---

## 📊 API Endpoints (for reference)

```
GET  /api/teacher/student-progress       - Get all students
POST /api/teacher/sync-from-sheets       - Sync from Google Sheets
POST /api/teacher/refresh-student/:id    - Refresh individual student
POST /api/coding-profiles/:userId        - Save coding profiles
```

---

## 🎉 Success!

You now have a fully functional Teacher Dashboard that:
- ✅ Shows all 72+ students at once
- ✅ Displays LeetCode & HackerRank progress
- ✅ Opens student profiles with one click
- ✅ Syncs automatically from Google Sheets
- ✅ Exports data for reports
- ✅ Refreshes stats in real-time

**Happy Teaching! 🚀**
