
const checkTimeLogic = (settingsTime, systemTimeStr) => {
    // Mock current time
    const [h, m] = systemTimeStr.split(':').map(Number);
    const now = new Date();
    now.setHours(h);
    now.setMinutes(m);
    now.setSeconds(0);

    const currentTime = systemTimeStr;

    // Logic from notificationService
    if (settingsTime) {
        const [setHours, setMinutes] = settingsTime.split(':').map(Number);
        const scheduleTime = new Date(); // uses 'now' date
        scheduleTime.setHours(setHours);
        scheduleTime.setMinutes(setMinutes);
        scheduleTime.setSeconds(0);

        console.log(`Schedule Time (Original): ${scheduleTime.toLocaleTimeString()}`);

        // Subtract 10 minutes
        scheduleTime.setMinutes(scheduleTime.getMinutes() - 10);
        console.log(`Schedule Time (Minus 10): ${scheduleTime.toLocaleTimeString()}`);

        const notifyHours = scheduleTime.getHours().toString().padStart(2, '0');
        const notifyMinutes = scheduleTime.getMinutes().toString().padStart(2, '0');
        const notifyTime = `${notifyHours}:${notifyMinutes}`;

        console.log(`Current: ${currentTime}, NotifyTarget: ${notifyTime}`);
        return currentTime === notifyTime;
    }
    return false;
}

// Test cases
console.log('Test 1: Set 10:00, Current 09:50 ->', checkTimeLogic('10:00', '09:50'));
console.log('Test 2: Set 10:05, Current 09:55 ->', checkTimeLogic('10:05', '09:55'));
console.log('Test 3: Set 00:05, Current 23:55 (Prev Day?) ->', checkTimeLogic('00:05', '23:55'));
// Note: Test 3 might fail if 'now' date is same for scheduleTime construction.
// validation of day-rollover in simplistic logic:
// If I enable it today. set 00:05.
// scheduleTime = Today 00:05.
// -10 mins = Yesterday 23:55.
// currentTime = Today 23:55.
// "23:55" == "23:55". It MATCHES!
// So it works for next-day early morning settings too, effectively.
