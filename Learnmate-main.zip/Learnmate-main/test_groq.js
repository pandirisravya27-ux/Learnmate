
const apiKey = process.env.GROQ_API_KEY || '';

async function testGroq(modelName) {
    console.log(`Testing Groq API with ${modelName}...`);
    try {
        const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                messages: [{ role: "user", content: "Hello, strictly answer with 'OK'" }],
                model: modelName
            })
        });

        const data = await response.json();

        if (!response.ok) {
            console.error("Error:", response.status);
            console.log(JSON.stringify(data, null, 2));
        } else {
            console.log("Success!");
            console.log("Response:", data.choices?.[0]?.message?.content);
        }
    } catch (error) {
        console.error("Exception:", error);
    }
}

async function runTests() {
    await testGroq('llama-3.1-8b-instant');
    await testGroq('llama-3.1-70b-versatile');
}

runTests();
