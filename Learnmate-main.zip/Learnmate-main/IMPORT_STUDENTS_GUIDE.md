# 📊 Quick Start: Import Your Student Data

You have **3 options** to import your 72 students from the Google Sheet:

---

## ✅ **OPTION 1: Share Google Sheet** (Recommended - Auto-sync)

### Steps:
1. Open your spreadsheet: https://docs.google.com/spreadsheets/d/10mH776E5msSAQ2w1DdZHp7yvCTlUD1K7dPRrU6_W8Aw/edit

2. Click **"Share"** button (top-right)

3. Add this email: `learnmate@mindful-syntax-481515-e1.iam.gserviceaccount.com`

4. Set permission to **"Viewer"**

5. Click **"Share"**

6. Go to Teacher Dashboard → Click **"📊 Sync from Sheets"**

7. Done! All students imported automatically ✅

---

## ⚡ **OPTION 2: Import CSV** (Fastest - Manual)

### Steps:
1. Open your Google Sheet

2. **File → Download → CSV (.csv)**

3. Go to Teacher Dashboard

4. Click **"📂 Import CSV"**

5. Select the downloaded CSV file

6. Done! All students imported ✅

### Expected CSV Format:
```
Name,Email,Roll Number,LeetCode URL,HackerRank URL
Student Name,email@example.com,001,https://leetcode.com/username,https://hackerrank.com/profile/username
```

---

## 🔄 **OPTION 3: Manual Entry** (For small numbers)

Students can add their own profiles:
1. Student logs in
2. Goes to **Dashboard → Coding Profiles**
3. Enters LeetCode and HackerRank usernames
4. Saves

---

## 🚀 After Import - Fetch Progress

1. Go to **Teacher Dashboard**

2. Click **"🔄 Refresh All"**

3. Wait 10-30 seconds (fetching data for 72 students)

4. View all student progress! 🎉

---

## 📋 What Gets Imported:

- ✅ Student Name
- ✅ Student Email
- ✅ Roll Number
- ✅ LeetCode Username (extracted from URL)
- ✅ HackerRank Username (extracted from URL)

Then the system automatically fetches:
- ✅ LeetCode problems solved (Easy/Medium/Hard)
- ✅ LeetCode global ranking
- ✅ HackerRank total score
- ✅ HackerRank badges

---

## 🎯 Quick Test

Want to test with a few students first?

1. Create a small CSV file with 3-5 students
2. Use **"📂 Import CSV"**
3. Click **"🔄 Refresh All"**
4. See the results!

Then import all 72 when ready.

---

## 💡 Tips

- Default password for auto-created accounts: `default123`
- Students can change password after first login
- You can re-import to update profiles
- "View Profiles" button opens both LeetCode & HackerRank

---

**Ready to go! Choose your option and import now! 🚀**
