# 🚀 Quick Import: Connect Your Google Sheet Data

## ⚡ FASTEST METHOD - CSV Import (5 minutes)

### Step 1: Download Your Google Sheet as CSV

1. Open your sheet: https://docs.google.com/spreadsheets/d/10mH776E5msSAQ2w1DdZHp7yvCTlUD1K7dPRrU6_W8Aw/edit
2. Click **File → Download → Comma Separated Values (.csv)**
3. Save the file (it will be named something like "Sheet1.csv")

### Step 2: Import into Teacher Dashboard

1. Go to **http://localhost:5173**
2. Login to your account
3. Click **"👨‍🏫 Teacher Dashboard"** in the sidebar
4. Click the **"📂 Import CSV"** button (orange button)
5. Select the CSV file you just downloaded
6. Wait for the import to complete ✅

### Step 3: Fetch Student Progress

1. Click **"🔄 Refresh All"** button (green button)
2. Wait 10-30 seconds while the system fetches data from LeetCode and HackerRank
3. Done! You'll see all 72 students with their progress! 🎉

---

## 🔄 ALTERNATIVE METHOD - Google Sheets Sync (Auto-updates)

If you want automatic syncing from Google Sheets:

### Step 1: Share Your Google Sheet

1. Open: https://docs.google.com/spreadsheets/d/10mH776E5msSAQ2w1DdZHp7yvCTlUD1K7dPRrU6_W8Aw/edit
2. Click **"Share"** button (top-right)
3. Add this email: `learnmate@mindful-syntax-481515-e1.iam.gserviceaccount.com`
4. Set permission: **"Viewer"**
5. Click **"Share"**

### Step 2: Sync from Dashboard

1. Go to Teacher Dashboard
2. Click **"📊 Sync from Sheets"** button (purple button)
3. All students will be imported automatically!
4. Click **"🔄 Refresh All"** to fetch their progress

---

## 📋 Expected CSV/Sheet Format

Your sheet should have these columns (in any order):

| Name | Email | Roll Number | LeetCode URL | HackerRank URL |
|------|-------|-------------|--------------|----------------|
| Student Name | email@example.com | 001 | https://leetcode.com/username | https://hackerrank.com/profile/username |

The system will automatically:
- Extract usernames from URLs
- Create student accounts (password: `default123`)
- Fetch their coding statistics
- Display progress in the dashboard

---

## 🎯 What You'll See After Import

For each student:
- ✅ Name, Email, Roll Number
- ✅ LeetCode profile link + problems solved (Easy/Medium/Hard)
- ✅ HackerRank profile link + score & badges
- ✅ "View Profiles" button to open both profiles
- ✅ Last updated timestamp

---

## 💡 Quick Troubleshooting

**CSV import fails?**
- Make sure the CSV has headers in the first row
- Check that URLs are complete (starting with https://)

**No stats showing after import?**
- Click "🔄 Refresh All" button
- Wait for the API calls to complete
- Some students might not have public profiles

**Google Sheets sync fails?**
- Verify you shared with the correct service account email
- Make sure permission is set to "Viewer" or higher

---

**Ready? Download your CSV and import now! It takes just 2 minutes! 🚀**
